# Sprint 3 — Webinars 11 y 12

## SQL financiero con VS Code, DuckDB y Parquet local

Este proyecto acompaña dos clases del Sprint 3:

- **Webinar 11:** KPIs financieros con SQL.
- **Webinar 12:** práctica guiada de SQL aplicada a métricas de negocio.

El flujo de trabajo está pensado para preparar a los estudiantes para sesiones posteriores con **Git** y **notebooks de Jupyter**.

---

## Herramientas

Usaremos:

- Visual Studio Code
- SQLTools
- DuckDB Driver for SQLTools
- DuckDB como motor SQL local
- Archivos `.parquet` descargados localmente

No usaremos:

- SQL Workbench en navegador
- URLs de GitHub dentro de SQL
- `INSTALL httpfs`
- `LOAD httpfs`
- Terminal como flujo principal de clase

---

## Estructura del proyecto

```text
bookstore_finance_sql_vscode/
├── bookstore.duckdb
├── data/
│   ├── duckdb_bookstore_customers.parquet
│   ├── duckdb_bookstore_products.parquet
│   ├── duckdb_bookstore_orders.parquet
│   ├── duckdb_bookstore_order_items.parquet
│   ├── duckdb_bookstore_payments.parquet
│   └── duckdb_bookstore_campaigns.parquet
├── sql/
│   ├── 00_test_connection.sql
│   ├── 01_setup_views_relative.sql
│   ├── 01b_setup_views_absolute_path_template.sql
│   ├── 02_data_dictionary_and_sanity_checks.sql
│   ├── 03_w11_revenue_cost_margin.sql
│   ├── 04_w11_roi_campanas.sql
│   ├── 05_w11_validaciones_reportes.sql
│   ├── 06_w11_tendencias_mensuales.sql
│   ├── 07_w12_practica_guiada.sql
│   ├── 08_w12_retos.sql
│   └── 99_soluciones_webinar12.sql
├── notebooks/
│   ├── Sprint03_Webinar11_Teorico_SQL_VSCode_DuckDB_Parquet_Local.ipynb
│   └── Sprint03_Webinar12_Practico_SQL_VSCode_DuckDB_Parquet_Local.ipynb
└── .vscode/
    └── extensions.json
```

---

## Primer uso

1. Descomprime el ZIP.
2. Abre VS Code.
3. Selecciona **File > Open Folder**.
4. Abre la carpeta completa `bookstore_finance_sql_vscode`.
5. Instala las extensiones recomendadas cuando VS Code las sugiera:
   - SQLTools
   - DuckDB Driver for SQLTools
   - Python
   - Jupyter
6. Crea una conexión DuckDB apuntando al archivo `bookstore.duckdb`.
7. Ejecuta `sql/00_test_connection.sql`.
8. Ejecuta `sql/01_setup_views_relative.sql`.
9. Ejecuta `sql/02_data_dictionary_and_sanity_checks.sql`.

---

## Si falla la ruta relativa

Si aparece un error parecido a:

```text
No files found that match the pattern
```

abre:

```text
sql/01b_setup_views_absolute_path_template.sql
```

Cambia esta línea:

```sql
SET VARIABLE data_folder = 'C:/CAMBIA_ESTA_RUTA/bookstore_finance_sql_vscode/data';
```

por la ruta real de tu carpeta `data`.

En Windows usa `/` en lugar de `\`.

Ejemplo:

```sql
SET VARIABLE data_folder = 'C:/Users/tu_usuario/Downloads/bookstore_finance_sql_vscode/data';
```

---

## Modelo de datos

Las vistas principales son:

| Vista | Descripción |
|---|---|
| `customers` | clientes y segmentos |
| `products` | catálogo de libros, categorías, precios y costos |
| `orders` | órdenes, fechas, estado, método de pago y promo code |
| `order_items` | detalle de productos por orden |
| `payments` | valores pagados, descuentos, impuestos y envío |
| `campaigns` | campañas asociadas a códigos promocionales |

Relaciones principales:

```text
customers.customer_id  → orders.customer_id
orders.order_id        → order_items.order_id
orders.order_id        → payments.order_id
products.product_id    → order_items.product_id
campaigns.promo_code   → orders.promo_code
```

---

## Conteos esperados

| Vista | Filas |
|---|---:|
| `customers` | 200 |
| `products` | 80 |
| `orders` | 600 |
| `order_items` | 1125 |
| `payments` | 600 |
| `campaigns` | 3 |

---

## Supuesto financiero de clase

Para reportes financieros, usaremos como regla base:

```sql
WHERE o.status NOT IN ('cancelled', 'refunded')
```

Esto evita mezclar órdenes canceladas o reembolsadas con revenue operativo.

---

## Orden sugerido para Webinar 11

1. `00_test_connection.sql`
2. `01_setup_views_relative.sql`
3. `02_data_dictionary_and_sanity_checks.sql`
4. `03_w11_revenue_cost_margin.sql`
5. `04_w11_roi_campanas.sql`
6. `05_w11_validaciones_reportes.sql`
7. `06_w11_tendencias_mensuales.sql`

---

## Orden sugerido para Webinar 12

1. `00_test_connection.sql`
2. `01_setup_views_relative.sql`
3. `02_data_dictionary_and_sanity_checks.sql`
4. `07_w12_practica_guiada.sql`
5. `08_w12_retos.sql`
6. `99_soluciones_webinar12.sql` solo después de intentar resolver.

