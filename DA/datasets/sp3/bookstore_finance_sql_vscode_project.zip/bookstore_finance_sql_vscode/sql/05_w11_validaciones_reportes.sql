-- Webinar 11 — Validaciones antes de reportar KPIs.

-- 1) Órdenes sin items
SELECT
    COUNT(*) AS orders_without_items
FROM orders AS o
LEFT JOIN order_items AS oi
    ON o.order_id = oi.order_id
WHERE oi.order_id IS NULL;

-- 2) Items sin producto
SELECT
    COUNT(*) AS items_without_product
FROM order_items AS oi
LEFT JOIN products AS p
    ON oi.product_id = p.product_id
WHERE p.product_id IS NULL;

-- 3) Órdenes sin pago
SELECT
    COUNT(*) AS orders_without_payment
FROM orders AS o
LEFT JOIN payments AS pay
    ON o.order_id = pay.order_id
WHERE pay.order_id IS NULL;

-- 4) Comparación de filas antes y después del join orders + order_items
SELECT
    COUNT(*) AS rows_after_join,
    COUNT(DISTINCT o.order_id) AS distinct_orders_after_join
FROM orders AS o
JOIN order_items AS oi
    ON o.order_id = oi.order_id;

-- 5) Reporte listo para stakeholder por categoría
SELECT
    p.category,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(oi.quantity) AS units_sold,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue,
    SUM(oi.quantity * p.cost) AS cost,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost) AS gross_profit,
    100 * (
        SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost)
    ) / NULLIF(SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)), 0) AS margin_pct
FROM orders AS o
JOIN order_items AS oi
    ON o.order_id = oi.order_id
JOIN products AS p
    ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY p.category
HAVING SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) > 0
ORDER BY gross_profit DESC;
