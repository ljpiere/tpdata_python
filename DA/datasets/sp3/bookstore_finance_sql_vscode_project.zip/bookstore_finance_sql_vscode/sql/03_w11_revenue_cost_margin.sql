-- Webinar 11 — KPIs financieros: revenue, cost, gross_profit y margin_pct.
--
-- Supuesto de negocio:
-- Para reportes financieros usamos órdenes no canceladas ni reembolsadas.
-- Por eso filtramos status NOT IN ('cancelled', 'refunded').

-- 1) Revenue y cost por categoría
SELECT
    p.category,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(oi.quantity) AS units_sold,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue,
    SUM(oi.quantity * p.cost) AS cost
FROM orders AS o
JOIN order_items AS oi
    ON o.order_id = oi.order_id
JOIN products AS p
    ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY p.category
ORDER BY revenue DESC;

-- 2) Gross profit y margin_pct por categoría
SELECT
    p.category,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue,
    SUM(oi.quantity * p.cost) AS cost,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost) AS gross_profit,
    100 * (
        SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost)
    ) / NULLIF(SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)), 0) AS margin_pct
FROM orders AS o
JOIN order_items AS oi
    ON o.order_id = oi.order_id
JOIN products AS p
    ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY p.category
ORDER BY gross_profit DESC;

-- 3) Top 10 productos con mayor revenue
SELECT
    p.product_id,
    p.title,
    p.category,
    SUM(oi.quantity) AS units_sold,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue,
    SUM(oi.quantity * p.cost) AS cost,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost) AS gross_profit
FROM orders AS o
JOIN order_items AS oi
    ON o.order_id = oi.order_id
JOIN products AS p
    ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY
    p.product_id,
    p.title,
    p.category
ORDER BY revenue DESC
LIMIT 10;
