-- Webinar 12 — Soluciones de referencia.
-- Úsalas después de intentar los ejercicios.

-- Ejercicio 0
SELECT
    o.status,
    pay.payment_method,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(pay.amount_paid) AS total_pagado
FROM orders AS o
JOIN payments AS pay
    ON o.order_id = pay.order_id
GROUP BY
    o.status,
    pay.payment_method
ORDER BY total_pagado DESC;

-- Ejercicio 1
SELECT
    c.segment,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(pay.amount_paid) AS total_pagado,
    SUM(pay.amount_paid) / NULLIF(COUNT(DISTINCT o.order_id), 0) AS avg_ticket
FROM customers AS c
JOIN orders AS o
    ON c.customer_id = o.customer_id
JOIN payments AS pay
    ON o.order_id = pay.order_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY c.segment
ORDER BY total_pagado DESC;

-- Ejercicio 2
SELECT
    p.category,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue
FROM orders AS o
JOIN order_items AS oi
    ON o.order_id = oi.order_id
JOIN products AS p
    ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY p.category
ORDER BY revenue DESC;

-- Ejercicio 3
SELECT
    p.product_id,
    p.title,
    p.category,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue
FROM orders AS o
JOIN order_items AS oi
    ON o.order_id = oi.order_id
JOIN products AS p
    ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY
    p.product_id,
    p.title,
    p.category
ORDER BY revenue DESC
LIMIT 5;

-- Ejercicio 4
SELECT
    p.category,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue,
    SUM(oi.quantity * p.cost) AS cost,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost) AS gross_profit,
    100 * (
        SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost)
    ) / NULLIF(SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)), 0) AS margin_pct
FROM orders AS o
JOIN order_items AS oi
    ON o.order_id = oi.order_id
JOIN products AS p
    ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY p.category
ORDER BY gross_profit DESC;

-- Ejercicio 5
SELECT
    CASE
        WHEN o.promo_code IS NULL THEN 'sin_promo'
        ELSE 'con_promo'
    END AS grupo_promo,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(pay.discount) AS total_descuento,
    SUM(pay.amount_paid) AS total_pagado,
    SUM(pay.amount_paid) / NULLIF(COUNT(DISTINCT o.order_id), 0) AS avg_ticket
FROM orders AS o
JOIN payments AS pay
    ON o.order_id = pay.order_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY grupo_promo
ORDER BY total_pagado DESC;

-- Ejercicio 6
SELECT
    c.promo_code,
    c.campaign_name,
    c.spend_usd,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(pay.net) AS net_revenue,
    100 * (SUM(pay.net) - c.spend_usd) / NULLIF(c.spend_usd, 0) AS roi_pct
FROM campaigns AS c
LEFT JOIN orders AS o
    ON c.promo_code = o.promo_code
    AND o.status NOT IN ('cancelled', 'refunded')
LEFT JOIN payments AS pay
    ON o.order_id = pay.order_id
GROUP BY
    c.promo_code,
    c.campaign_name,
    c.spend_usd
ORDER BY roi_pct DESC;

-- Reto A
SELECT
    o.status,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(pay.amount_paid) AS total_pagado
FROM orders AS o
JOIN payments AS pay
    ON o.order_id = pay.order_id
GROUP BY o.status
ORDER BY n_orders DESC;

-- Reto B
SELECT
    c.customer_id,
    c.customer_name,
    c.segment,
    c.city,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(pay.amount_paid) AS total_pagado
FROM customers AS c
JOIN orders AS o
    ON c.customer_id = o.customer_id
JOIN payments AS pay
    ON o.order_id = pay.order_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY
    c.customer_id,
    c.customer_name,
    c.segment,
    c.city
ORDER BY total_pagado DESC
LIMIT 10;

-- Reto C
SELECT
    p.category,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue,
    100 * (
        SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost)
    ) / NULLIF(SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)), 0) AS margin_pct
FROM orders AS o
JOIN order_items AS oi
    ON o.order_id = oi.order_id
JOIN products AS p
    ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY p.category
HAVING COUNT(DISTINCT o.order_id) < 100
ORDER BY margin_pct DESC;

-- Reto D
SELECT
    c.promo_code,
    c.campaign_name,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(pay.net) AS net_revenue,
    c.spend_usd,
    100 * (SUM(pay.net) - c.spend_usd) / NULLIF(c.spend_usd, 0) AS roi_pct
FROM campaigns AS c
LEFT JOIN orders AS o
    ON c.promo_code = o.promo_code
    AND o.status NOT IN ('cancelled', 'refunded')
LEFT JOIN payments AS pay
    ON o.order_id = pay.order_id
GROUP BY
    c.promo_code,
    c.campaign_name,
    c.spend_usd
ORDER BY roi_pct DESC, n_orders ASC;
