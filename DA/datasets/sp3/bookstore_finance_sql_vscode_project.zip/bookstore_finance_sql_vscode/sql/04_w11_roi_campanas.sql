-- Webinar 11 — ROI por campaña.
--
-- Nueva tabla del modelo:
-- campaigns
--
-- Llave de relación:
-- campaigns.promo_code = orders.promo_code
--
-- Fórmula:
-- ROI % = 100 * (net_revenue - spend_usd) / spend_usd

-- 1) Revisión de campañas disponibles
SELECT *
FROM campaigns
ORDER BY promo_code;

-- 2) Órdenes por campaña
SELECT
    c.promo_code,
    c.campaign_name,
    c.channel,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(pay.net) AS net_revenue,
    SUM(pay.discount) AS total_discount,
    SUM(pay.amount_paid) AS amount_paid
FROM campaigns AS c
LEFT JOIN orders AS o
    ON c.promo_code = o.promo_code
    AND o.status NOT IN ('cancelled', 'refunded')
LEFT JOIN payments AS pay
    ON o.order_id = pay.order_id
GROUP BY
    c.promo_code,
    c.campaign_name,
    c.channel
ORDER BY net_revenue DESC;

-- 3) ROI por campaña
SELECT
    c.promo_code,
    c.campaign_name,
    c.channel,
    c.spend_usd,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(pay.net) AS net_revenue,
    SUM(pay.discount) AS total_discount,
    SUM(pay.net) - c.spend_usd AS profit_after_spend,
    100 * (SUM(pay.net) - c.spend_usd) / NULLIF(c.spend_usd, 0) AS roi_pct
FROM campaigns AS c
LEFT JOIN orders AS o
    ON c.promo_code = o.promo_code
    AND o.status NOT IN ('cancelled', 'refunded')
LEFT JOIN payments AS pay
    ON o.order_id = pay.order_id
GROUP BY
    c.promo_code,
    c.campaign_name,
    c.channel,
    c.spend_usd
ORDER BY roi_pct DESC;
