-- Webinar 12 — Retos opcionales.

-- Reto A
-- Estados con mayor volumen de órdenes y total pagado.
-- Pregunta de negocio:
-- ¿Qué estados concentran más actividad y cuál parece más valioso?

-- Escribe tu consulta aquí:


-- Reto B
-- Top 10 clientes por gasto total.
-- Pregunta de negocio:
-- ¿Qué clientes podrían recibir una acción de fidelización?

-- Escribe tu consulta aquí:


-- Reto C
-- Categorías con margen alto pero bajo volumen.
-- Pregunta de negocio:
-- ¿Dónde podría existir oportunidad de crecimiento?

-- Escribe tu consulta aquí:


-- Reto D
-- Campañas con ROI alto pero bajo volumen.
-- Pregunta de negocio:
-- ¿Qué campaña parece eficiente pero todavía pequeña?

-- Escribe tu consulta aquí:
