-- Sprint 3 — Webinars 11 y 12
-- Setup de vistas sobre archivos Parquet locales.
--
-- IMPORTANTE:
-- 1. Abre la carpeta completa bookstore_finance_sql_vscode en VS Code.
-- 2. No abras archivos sueltos.
-- 3. Ejecuta este archivo conectado a bookstore.duckdb.
--
-- Si aparece un error tipo "No files found that match the pattern",
-- usa 01b_setup_views_absolute_path_template.sql y cambia la ruta absoluta.

DROP VIEW IF EXISTS customers;
DROP VIEW IF EXISTS products;
DROP VIEW IF EXISTS orders;
DROP VIEW IF EXISTS order_items;
DROP VIEW IF EXISTS payments;
DROP VIEW IF EXISTS campaigns;

CREATE OR REPLACE VIEW customers AS
SELECT *
FROM read_parquet('data/duckdb_bookstore_customers.parquet');

CREATE OR REPLACE VIEW products AS
SELECT *
FROM read_parquet('data/duckdb_bookstore_products.parquet');

CREATE OR REPLACE VIEW orders AS
SELECT *
FROM read_parquet('data/duckdb_bookstore_orders.parquet');

CREATE OR REPLACE VIEW order_items AS
SELECT *
FROM read_parquet('data/duckdb_bookstore_order_items.parquet');

CREATE OR REPLACE VIEW payments AS
SELECT *
FROM read_parquet('data/duckdb_bookstore_payments.parquet');

CREATE OR REPLACE VIEW campaigns AS
SELECT *
FROM read_parquet('data/duckdb_bookstore_campaigns.parquet');

SHOW TABLES;
