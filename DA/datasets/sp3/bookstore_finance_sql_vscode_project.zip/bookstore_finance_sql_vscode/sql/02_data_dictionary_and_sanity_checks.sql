-- Diccionario rápido y validaciones iniciales.

SHOW TABLES;

DESCRIBE customers;
DESCRIBE products;
DESCRIBE orders;
DESCRIBE order_items;
DESCRIBE payments;
DESCRIBE campaigns;

SELECT 'customers' AS tabla, COUNT(*) AS filas FROM customers
UNION ALL
SELECT 'products', COUNT(*) FROM products
UNION ALL
SELECT 'orders', COUNT(*) FROM orders
UNION ALL
SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL
SELECT 'payments', COUNT(*) FROM payments
UNION ALL
SELECT 'campaigns', COUNT(*) FROM campaigns;

-- Muestras rápidas
SELECT * FROM customers LIMIT 5;
SELECT * FROM products LIMIT 5;
SELECT * FROM orders LIMIT 5;
SELECT * FROM order_items LIMIT 5;
SELECT * FROM payments LIMIT 5;
SELECT * FROM campaigns LIMIT 5;

-- Validación de estados de orden
SELECT
    status,
    COUNT(*) AS n_orders
FROM orders
GROUP BY status
ORDER BY n_orders DESC;

-- Validación de campañas/promo codes
SELECT
    promo_code,
    COUNT(*) AS n_orders
FROM orders
GROUP BY promo_code
ORDER BY n_orders DESC;
