-- Sprint 3 — Webinars 11 y 12
-- Prueba mínima de conexión en VS Code + SQLTools + DuckDB.

SELECT
    'DuckDB está funcionando en VS Code' AS mensaje,
    version() AS duckdb_version,
    CURRENT_DATE AS fecha_actual;

SELECT *
FROM connection_test;
