-- Plantilla alternativa si la ruta relativa 'data/...' no funciona.
-- Cambia la ruta de data_folder por la ruta absoluta de tu carpeta data.
--
-- Windows: usa slash normal '/', no backslash '\'
-- Ejemplo:
-- SET VARIABLE data_folder = 'C:/Users/tu_usuario/Downloads/bookstore_finance_sql_vscode/data';
--
-- Mac:
-- SET VARIABLE data_folder = '/Users/tu_usuario/Downloads/bookstore_finance_sql_vscode/data';

SET VARIABLE data_folder = 'C:/CAMBIA_ESTA_RUTA/bookstore_finance_sql_vscode/data';

DROP VIEW IF EXISTS customers;
DROP VIEW IF EXISTS products;
DROP VIEW IF EXISTS orders;
DROP VIEW IF EXISTS order_items;
DROP VIEW IF EXISTS payments;
DROP VIEW IF EXISTS campaigns;

CREATE OR REPLACE VIEW customers AS
SELECT *
FROM read_parquet(getvariable('data_folder') || '/duckdb_bookstore_customers.parquet');

CREATE OR REPLACE VIEW products AS
SELECT *
FROM read_parquet(getvariable('data_folder') || '/duckdb_bookstore_products.parquet');

CREATE OR REPLACE VIEW orders AS
SELECT *
FROM read_parquet(getvariable('data_folder') || '/duckdb_bookstore_orders.parquet');

CREATE OR REPLACE VIEW order_items AS
SELECT *
FROM read_parquet(getvariable('data_folder') || '/duckdb_bookstore_order_items.parquet');

CREATE OR REPLACE VIEW payments AS
SELECT *
FROM read_parquet(getvariable('data_folder') || '/duckdb_bookstore_payments.parquet');

CREATE OR REPLACE VIEW campaigns AS
SELECT *
FROM read_parquet(getvariable('data_folder') || '/duckdb_bookstore_campaigns.parquet');

SHOW TABLES;
