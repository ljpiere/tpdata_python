-- Webinar 11 — Tendencias mensuales.

-- 1) Revenue, cost y margen por mes
SELECT
    DATE_TRUNC('month', CAST(o.order_date AS DATE)) AS order_month,
    COUNT(DISTINCT o.order_id) AS n_orders,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue,
    SUM(oi.quantity * p.cost) AS cost,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost) AS gross_profit,
    100 * (
        SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost)
    ) / NULLIF(SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)), 0) AS margin_pct
FROM orders AS o
JOIN order_items AS oi
    ON o.order_id = oi.order_id
JOIN products AS p
    ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY order_month
ORDER BY order_month;

-- 2) Productos con revenue alto y margen bajo
SELECT
    p.product_id,
    p.title,
    p.category,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue,
    SUM(oi.quantity * p.cost) AS cost,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost) AS gross_profit,
    100 * (
        SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
        - SUM(oi.quantity * p.cost)
    ) / NULLIF(SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)), 0) AS margin_pct
FROM orders AS o
JOIN order_items AS oi
    ON o.order_id = oi.order_id
JOIN products AS p
    ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled', 'refunded')
GROUP BY
    p.product_id,
    p.title,
    p.category
HAVING SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) > 500
ORDER BY margin_pct ASC, revenue DESC
LIMIT 10;
