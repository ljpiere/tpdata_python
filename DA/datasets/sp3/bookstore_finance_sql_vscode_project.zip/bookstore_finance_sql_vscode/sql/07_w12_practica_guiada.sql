-- Webinar 12 — Práctica guiada.
-- Usa este archivo para resolver los ejercicios sin mirar soluciones.

-- Ejercicio 0
-- Calcular, por estado de orden y método de pago:
-- - número de órdenes
-- - total pagado
-- Pista: une orders con payments usando order_id.

-- Escribe tu consulta aquí:


-- Ejercicio 1
-- Órdenes por segmento de cliente:
-- - segment
-- - número de órdenes
-- - total pagado
-- - ticket promedio
-- Pista: customers -> orders -> payments.

-- Escribe tu consulta aquí:


-- Ejercicio 2
-- Revenue por categoría.
-- Fórmula: quantity * unit_price * (1 - discount_rate)
-- Pista: order_items -> products.

-- Escribe tu consulta aquí:


-- Ejercicio 3
-- Top 5 productos por revenue.
-- Debes mostrar product_id, title, category y revenue.

-- Escribe tu consulta aquí:


-- Ejercicio 4
-- Margen bruto por categoría.
-- Debes calcular revenue, cost, gross_profit y margin_pct.

-- Escribe tu consulta aquí:


-- Ejercicio 5
-- Comparar órdenes con promo vs sin promo.
-- Debes obtener grupo_promo, n_orders, total_descuento, total_pagado y avg_ticket.

-- Escribe tu consulta aquí:


-- Ejercicio 6
-- ROI por campaña usando la tabla campaigns.
-- Debes obtener promo_code, campaign_name, spend_usd, net_revenue y roi_pct.

-- Escribe tu consulta aquí:
