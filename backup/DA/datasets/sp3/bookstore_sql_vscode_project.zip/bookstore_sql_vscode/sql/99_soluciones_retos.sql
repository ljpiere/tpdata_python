-- Soluciones de referencia para retos opcionales

-- Reto 1: clientes con 3 o más órdenes
SELECT
  c.customer_id,
  c.customer_name,
  COUNT(DISTINCT o.order_id) AS n_orders,
  SUM(p.amount_paid) AS total_pagado
FROM customers c
JOIN orders o
  ON c.customer_id = o.customer_id
JOIN payments p
  ON o.order_id = p.order_id
GROUP BY
  c.customer_id,
  c.customer_name
HAVING COUNT(DISTINCT o.order_id) >= 3
ORDER BY total_pagado DESC;

-- Reto 2: productos con descuento promedio mayor o igual a 20%
SELECT
  pr.product_id,
  pr.title,
  pr.category,
  AVG(oi.discount_rate) AS avg_discount
FROM products pr
JOIN order_items oi
  ON pr.product_id = oi.product_id
GROUP BY
  pr.product_id,
  pr.title,
  pr.category
HAVING AVG(oi.discount_rate) >= 0.20
ORDER BY avg_discount DESC;

-- Reto 3: categorías con revenue menor a 10000 y margen mayor a 45%
SELECT
  pr.category,
  SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue,
  SUM(oi.quantity * pr.cost) AS cost,
  SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
    - SUM(oi.quantity * pr.cost) AS gross_profit,
  CASE
    WHEN SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) = 0 THEN NULL
    ELSE 100 * (
      SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
      - SUM(oi.quantity * pr.cost)
    ) / SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
  END AS margin_pct
FROM order_items oi
JOIN products pr
  ON oi.product_id = pr.product_id
GROUP BY pr.category
HAVING
  SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) < 10000
  AND CASE
    WHEN SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) = 0 THEN NULL
    ELSE 100 * (
      SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
      - SUM(oi.quantity * pr.cost)
    ) / SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
  END > 45
ORDER BY margin_pct DESC;
