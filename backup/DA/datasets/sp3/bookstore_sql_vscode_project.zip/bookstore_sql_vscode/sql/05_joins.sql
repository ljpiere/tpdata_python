-- Joins
-- Objetivo: unir tablas para responder preguntas de negocio.

-- Órdenes con información de cliente y pago
SELECT
  o.order_id,
  o.order_date,
  o.status,
  c.customer_name,
  c.segment,
  p.payment_method,
  p.amount_paid
FROM orders o
JOIN customers c
  ON o.customer_id = c.customer_id
JOIN payments p
  ON o.order_id = p.order_id
ORDER BY o.order_date DESC
LIMIT 20;

-- Total pagado por segmento de cliente
SELECT
  c.segment,
  COUNT(DISTINCT o.order_id) AS n_orders,
  SUM(p.amount_paid) AS total_pagado,
  SUM(p.amount_paid) / COUNT(DISTINCT o.order_id) AS avg_ticket
FROM customers c
JOIN orders o
  ON c.customer_id = o.customer_id
JOIN payments p
  ON o.order_id = p.order_id
GROUP BY c.segment
ORDER BY total_pagado DESC;

-- Top 5 productos por revenue
SELECT
  pr.product_id,
  pr.title,
  pr.category,
  SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue
FROM order_items oi
JOIN products pr
  ON oi.product_id = pr.product_id
GROUP BY
  pr.product_id,
  pr.title,
  pr.category
ORDER BY revenue DESC
LIMIT 5;
