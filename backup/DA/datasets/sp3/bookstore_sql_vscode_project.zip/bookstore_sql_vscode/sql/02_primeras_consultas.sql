-- Primeras consultas SQL
-- Ejecuta primero 01_setup_views.sql.

-- 1. Ver una muestra de productos
SELECT *
FROM products
LIMIT 10;

-- 2. Elegir columnas específicas
SELECT
  product_id,
  title,
  category,
  price,
  cost
FROM products
LIMIT 10;

-- 3. Ordenar productos por precio
SELECT
  product_id,
  title,
  category,
  price
FROM products
ORDER BY price DESC
LIMIT 10;

-- 4. Filtrar productos activos
SELECT
  product_id,
  title,
  category,
  price
FROM products
WHERE is_active = TRUE
ORDER BY price DESC
LIMIT 10;
