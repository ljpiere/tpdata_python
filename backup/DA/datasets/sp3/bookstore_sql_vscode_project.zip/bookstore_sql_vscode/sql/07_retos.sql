-- Retos opcionales

-- Reto 1: clientes con 3 o más órdenes.
-- Mostrar customer_id, customer_name, n_orders, total_pagado.

-- Escribe tu consulta aquí.


-- Reto 2: productos con descuento promedio mayor o igual a 20%.
-- Mostrar product_id, title, category, avg_discount.

-- Escribe tu consulta aquí.


-- Reto 3: categorías con revenue menor a 10000 y margen mayor a 45%.
-- Mostrar category, revenue, cost, gross_profit, margin_pct.

-- Escribe tu consulta aquí.
