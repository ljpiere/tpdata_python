-- Filtros y ordenamiento
-- Objetivo: practicar WHERE, operadores lógicos y ORDER BY.

-- Órdenes completadas desde 2025
SELECT
  order_id,
  customer_id,
  order_date,
  status,
  payment_method
FROM orders
WHERE status = 'completed'
  AND order_date >= '2025-01-01'
ORDER BY order_date DESC
LIMIT 20;

-- Productos de categorías seleccionadas
SELECT
  product_id,
  title,
  category,
  price
FROM products
WHERE category IN ('Arte', 'Historia')
ORDER BY category, price DESC;

-- Clientes de Bogotá o Medellín adquiridos por Web
SELECT
  customer_id,
  customer_name,
  city,
  segment,
  acquisition_channel
FROM customers
WHERE city IN ('Bogotá', 'Medellín')
  AND acquisition_channel = 'Web'
ORDER BY city, customer_name;
