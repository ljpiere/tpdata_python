-- Agregaciones
-- Objetivo: pasar de filas individuales a indicadores resumidos.

-- Órdenes por estado
SELECT
  status,
  COUNT(*) AS n_orders
FROM orders
GROUP BY status
ORDER BY n_orders DESC;

-- Clientes por segmento
SELECT
  segment,
  COUNT(*) AS n_customers
FROM customers
GROUP BY segment
ORDER BY n_customers DESC;

-- Revenue por categoría
SELECT
  pr.category,
  SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue
FROM order_items oi
JOIN products pr
  ON oi.product_id = pr.product_id
GROUP BY pr.category
ORDER BY revenue DESC;

-- Categorías con revenue mayor a 10000
SELECT
  pr.category,
  SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue
FROM order_items oi
JOIN products pr
  ON oi.product_id = pr.product_id
GROUP BY pr.category
HAVING SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) > 10000
ORDER BY revenue DESC;
