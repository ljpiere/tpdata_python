-- Sprint 3 · Setup del dataset Bookstore
-- Objetivo: crear vistas SQL sobre archivos Parquet locales.
-- Importante: abre la carpeta completa bookstore_sql_vscode en VS Code.
-- Las rutas relativas 'data/...' funcionan cuando el proyecto está abierto desde su carpeta raíz.

CREATE OR REPLACE VIEW customers AS
SELECT *
FROM read_parquet('data/duckdb_bookstore_customers.parquet');

CREATE OR REPLACE VIEW products AS
SELECT *
FROM read_parquet('data/duckdb_bookstore_products.parquet');

CREATE OR REPLACE VIEW orders AS
SELECT *
FROM read_parquet('data/duckdb_bookstore_orders.parquet');

CREATE OR REPLACE VIEW order_items AS
SELECT *
FROM read_parquet('data/duckdb_bookstore_order_items.parquet');

CREATE OR REPLACE VIEW payments AS
SELECT *
FROM read_parquet('data/duckdb_bookstore_payments.parquet');

-- Validación rápida: las cinco vistas deben aparecer.
SHOW TABLES;

-- Conteos esperados:
-- customers   200
-- products    80
-- orders      600
-- order_items 1125
-- payments    600
SELECT 'customers' AS tabla, COUNT(*) AS filas FROM customers
UNION ALL
SELECT 'products', COUNT(*) FROM products
UNION ALL
SELECT 'orders', COUNT(*) FROM orders
UNION ALL
SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL
SELECT 'payments', COUNT(*) FROM payments;
