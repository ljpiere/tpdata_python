-- Práctica guiada: KPIs de negocio
-- Usa este archivo en el Webinar 10.

-- Ejercicio 0: resumen por estado de orden y método de pago
SELECT
  o.status,
  p.payment_method,
  COUNT(DISTINCT o.order_id) AS n_orders,
  SUM(p.amount_paid) AS total_pagado
FROM orders o
JOIN payments p
  ON o.order_id = p.order_id
GROUP BY
  o.status,
  p.payment_method
ORDER BY total_pagado DESC;

-- Ejercicio 1: margen bruto por categoría
SELECT
  pr.category,
  SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) AS revenue,
  SUM(oi.quantity * pr.cost) AS cost,
  SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
    - SUM(oi.quantity * pr.cost) AS gross_profit,
  CASE
    WHEN SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate)) = 0 THEN NULL
    ELSE 100 * (
      SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
      - SUM(oi.quantity * pr.cost)
    ) / SUM(oi.quantity * oi.unit_price * (1 - oi.discount_rate))
  END AS margin_pct
FROM order_items oi
JOIN products pr
  ON oi.product_id = pr.product_id
GROUP BY pr.category
ORDER BY revenue DESC;

-- Ejercicio 2: comparación de órdenes con y sin promoción
SELECT
  CASE
    WHEN o.promo_code IS NULL OR o.promo_code = '' THEN 'sin_promo'
    ELSE 'con_promo'
  END AS grupo_promo,
  COUNT(DISTINCT o.order_id) AS n_orders,
  SUM(p.discount) AS total_descuento,
  SUM(p.amount_paid) AS total_pagado,
  SUM(p.amount_paid) / COUNT(DISTINCT o.order_id) AS avg_ticket
FROM orders o
JOIN payments p
  ON o.order_id = p.order_id
GROUP BY grupo_promo
HAVING COUNT(DISTINCT o.order_id) >= 50
ORDER BY total_pagado DESC;
