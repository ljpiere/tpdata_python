-- Sprint 3 · Webinar 9/10
-- Prueba mínima de conexión DuckDB en VS Code.
-- Ejecuta este archivo después de crear la conexión a bookstore.duckdb.

SELECT 'DuckDB está funcionando desde VS Code' AS mensaje;
