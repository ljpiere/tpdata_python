# Bookstore SQL · VS Code + DuckDB

Proyecto de clase para introducir SQL usando VS Code, DuckDB y archivos Parquet locales.

## Estructura

```text
bookstore_sql_vscode/
├── bookstore.duckdb
├── data/
│   ├── duckdb_bookstore_customers.parquet
│   ├── duckdb_bookstore_products.parquet
│   ├── duckdb_bookstore_orders.parquet
│   ├── duckdb_bookstore_order_items.parquet
│   └── duckdb_bookstore_payments.parquet
└── sql/
    ├── 00_test_connection.sql
    ├── 01_setup_views.sql
    ├── 02_primeras_consultas.sql
    ├── 03_filtros_y_ordenamiento.sql
    ├── 04_agregaciones.sql
    ├── 05_joins.sql
    ├── 06_practica_kpis.sql
    ├── 07_retos.sql
    └── 99_soluciones_retos.sql
```

## Instalación sugerida

1. Instala Visual Studio Code.
2. En VS Code, instala la extensión **SQLTools**.
3. Instala también **DuckDB Driver for SQLTools**.
4. Abre la carpeta completa `bookstore_sql_vscode` desde `File > Open Folder`.
5. Crea una conexión DuckDB usando el archivo `bookstore.duckdb`.
6. Ejecuta `sql/00_test_connection.sql`.
7. Ejecuta `sql/01_setup_views.sql`.
8. Continúa con los archivos SQL en orden.

## Regla importante

No abras archivos SQL sueltos. Abre la carpeta completa `bookstore_sql_vscode`. Esto ayuda a que las rutas relativas como `data/duckdb_bookstore_products.parquet` funcionen correctamente.

## Validación esperada

Después de ejecutar `01_setup_views.sql`, los conteos esperados son:

| tabla | filas |
|---|---:|
| customers | 200 |
| products | 80 |
| orders | 600 |
| order_items | 1125 |
| payments | 600 |

## Errores frecuentes

- `IO Error: No files found that match the pattern`: VS Code no está abierto en la carpeta correcta o la carpeta `data` no está junto al archivo `bookstore.duckdb`.
- `Catalog Error: Table ... does not exist`: falta ejecutar `01_setup_views.sql`.
- `Binder Error`: hay una columna en `SELECT` que no está agregada ni incluida en `GROUP BY`.
